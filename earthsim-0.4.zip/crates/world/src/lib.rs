//! `world` — streaming the planet: geodesy, tile scheme, OpenStreetMap parsing, building Stage A,
//! disk cache, fetchers and the tile streamer. std only.
pub mod cache;
pub mod fetch;
pub mod geo;
pub mod osm;
pub mod stage_a;
pub mod streamer;
pub mod tiles;
