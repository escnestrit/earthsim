//! Game state: fixed-step physics, camera, input mapping and HUD data. Platform independent.
use crate::m4::{self, V3f};
use crate::render::{FrameParams, HudData};
use phys::{Driver, FlatGround, Keys, SoftVehicle, StaticWorld, Vehicle, VehicleParams};
use scene::{car_meshes, scene_meshes, MeshData, Scene};
use std::collections::HashMap;
use std::sync::Arc;
use world::streamer::{StreamEvent, Streamer};
use world::tiles::{TileId, ZOOM};

/// Changes to the GPU side that the game queues for the renderer.
pub enum RenderOp {
    AddTile(u64, Arc<Vec<MeshData>>),
    RemoveTile(u64),
    FollowGround(bool),
}

/// Places the F2 key jumps to.
pub const PRESETS: &[(&str, f64, f64)] = &[
    ("MINSK", 53.9045, 27.5615),
    ("PARIS", 48.8584, 2.2945),
    ("NEW YORK", 40.7580, -73.9855),
    ("TOKYO", 35.6595, 139.7005),
    ("LONDON", 51.5074, -0.1278),
    ("BERLIN", 52.5200, 13.4050),
];

struct Stream {
    streamer: Streamer,
    scenes: HashMap<u64, Arc<Scene>>,
    home: (String, f64, f64),
    preset: usize,
    place: String,
    /// Car is held still until the map around it has arrived.
    waiting: bool,
    wait_since: std::time::Instant,
    origin_latlon: (f64, f64),
}

pub const PHYS_DT: f64 = 0.001;
/// Rest height of the centre of gravity above the ground; the car mesh origin sits on the ground.
pub const CG_HEIGHT: f64 = 0.581;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Key {
    Up,
    Down,
    Left,
    Right,
    Handbrake,
    Camera,
    HourUp,
    HourDown,
    Lights,
    Respawn,
    Recover,
    Hud,
    Tcs,
    Abs,
    Help,
    Teleport,
    SoftBody,
}

pub struct Game {
    pub scene: Scene,
    pub meshes: Vec<MeshData>,
    pub scene_dirty: bool,
    pub world: StaticWorld,
    pub car: Vehicle,
    pub driver: Driver,
    pub keys: Keys,
    ground: FlatGround,
    spawn: scene::model::Spawn,
    acc: f64,
    pub hour: f32,
    pub cam_mode: u8,
    cam_yaw: f64,
    pub headlights: Option<bool>,
    pub show_hud: bool,
    pub show_help: bool,
    pub fps: f32,
    fps_acc: f32,
    fps_n: u32,
    pub draws: u32,
    pub triangles: u64,
    pub sim_steps_last_frame: u32,
    pub renderer_info: String,
    pub car_meshes: (MeshData, MeshData),
    pub render_ops: Vec<RenderOp>,
    pub soft: SoftVehicle,
    pub soft_on: bool,
    skin: crate::softmesh::SkinnedBody,
    pub deformed: Vec<f32>,
    /// Fixed camera (eye, target, fov) used for screenshots and tests instead of the follow cameras.
    pub cam_override: Option<(V3f, V3f, f32)>,
    stream: Option<Box<Stream>>,
}

impl Game {
    pub fn new(scene: Scene) -> Game {
        let ground = FlatGround { grip: 1.0 };
        let spawn = scene.spawn();
        let car = Vehicle::new(VehicleParams::sedan(), spawn.x, spawn.y, spawn.yaw, &ground);
        let driver = Driver::new(car.p.steer_max);
        let world = scene.static_world();
        let meshes = scene_meshes(&scene);
        let soft = SoftVehicle::new(VehicleParams::sedan(), spawn.x, spawn.y, spawn.yaw, &ground);
        let car_meshes = car_meshes();
        let skin = crate::softmesh::SkinnedBody::new(&car_meshes.0, &soft);
        Game {
            scene,
            meshes,
            scene_dirty: true,
            world,
            car,
            driver,
            keys: Keys::default(),
            ground,
            spawn,
            acc: 0.0,
            hour: 15.0,
            cam_mode: 0,
            cam_yaw: spawn.yaw,
            headlights: None,
            show_hud: true,
            show_help: true,
            fps: 0.0,
            fps_acc: 0.0,
            fps_n: 0,
            draws: 0,
            triangles: 0,
            sim_steps_last_frame: 0,
            renderer_info: String::new(),
            car_meshes,
            render_ops: Vec::new(),
            soft,
            soft_on: true,
            skin,
            deformed: Vec::new(),
            cam_override: None,
            stream: None,
        }
    }

    /// Streaming game: the world is loaded around the car while it drives. `home` is where it starts and where
    /// R brings it back to.
    pub fn new_streaming(streamer: Streamer, name: &str, lat: f64, lon: f64) -> Game {
        let mut g = Game::new(Scene::default());
        g.meshes.clear();
        g.world = StaticWorld::new(25.0);
        g.scene.meta.source = Some("(c) OPENSTREETMAP CONTRIBUTORS (ODBL)".into());
        g.scene.meta.terrain = String::new();
        g.render_ops.push(RenderOp::FollowGround(true));
        g.stream = Some(Box::new(Stream {
            streamer,
            scenes: HashMap::new(),
            home: (name.to_string(), lat, lon),
            preset: usize::MAX,
            place: name.to_string(),
            waiting: true,
            wait_since: std::time::Instant::now(),
            origin_latlon: (lat, lon),
        }));
        g
    }

    /// Put the car (rigid and soft model alike) on the ground, repaired, stopped or rolling at `speed`.
    fn place_car(&mut self, x: f64, y: f64, yaw: f64, speed: f64) {
        self.car.place(x, y, yaw, speed, &self.ground);
        self.soft.place(x, y, yaw, speed, &self.ground);
        self.sync_from_soft_if_on();
    }

    fn sync_from_soft_if_on(&mut self) {
        if !self.soft_on {
            return;
        }
        let s = &self.soft;
        self.car.pos = s.pos;
        self.car.q = s.q;
        self.car.vel = s.vel;
        self.car.omega = phys::V3::ZERO;
        self.car.wheels = s.wheels.clone();
        self.car.drive = s.drive.clone();
        self.car.impact = s.impact;
        self.car.accel = s.accel;
        self.skin.deform(&self.soft, &mut self.deformed);
    }

    /// The deformed body mesh in world coordinates when the soft-body model is active.
    pub fn deformed_body(&self) -> Option<&[f32]> {
        (self.soft_on && !self.deformed.is_empty()).then_some(self.deformed.as_slice())
    }

    pub fn is_streaming(&self) -> bool {
        self.stream.is_some()
    }

    pub fn take_render_ops(&mut self) -> Vec<RenderOp> {
        std::mem::take(&mut self.render_ops)
    }

    /// Jump to a new place: everything loaded is dropped, the car waits for the new map.
    pub fn teleport(&mut self, name: &str, lat: f64, lon: f64) {
        let Some(st) = self.stream.as_mut() else { return };
        let mut ev = Vec::new();
        st.streamer.set_origin(lat, lon, &mut ev);
        st.place = name.to_string();
        st.waiting = true;
        st.wait_since = std::time::Instant::now();
        st.origin_latlon = (lat, lon);
        self.apply_stream_events(ev, false);
        self.place_car(0.0, 0.0, 0.0, 0.0);
        self.driver = Driver::new(self.car.p.steer_max);
        self.cam_yaw = 0.0;
    }

    fn apply_stream_events(&mut self, events: Vec<StreamEvent>, shift_car: bool) {
        let Some(st) = self.stream.as_mut() else { return };
        let mut changed = false;
        for e in events {
            match e {
                StreamEvent::Add { tile, scene, meshes } => {
                    let key = tile.key();
                    for b in &scene.buildings {
                        self.world.add_poly_tagged(key, b.footprint.iter().map(|p| (p[0], p[1])).collect());
                    }
                    for t in &scene.trees {
                        self.world.add_circle_tagged(key, t[0], t[1], 0.35);
                    }
                    st.scenes.insert(key, scene);
                    self.render_ops.push(RenderOp::AddTile(key, meshes));
                    changed = true;
                }
                StreamEvent::Remove { tile } => {
                    let key = tile.key();
                    self.world.remove_tag(key);
                    st.scenes.remove(&key);
                    self.render_ops.push(RenderOp::RemoveTile(key));
                    changed = true;
                }
                StreamEvent::Rebased { old, new } => {
                    if shift_car {
                        let (la, lo, _) = old.from_local(self.car.pos.x, self.car.pos.y, 0.0);
                        let p = new.to_local(la, lo, 0.0);
                        let (dx, dy) = (p[0] - self.car.pos.x, p[1] - self.car.pos.y);
                        self.car.pos.x += dx;
                        self.car.pos.y += dy;
                        self.soft.pos.x += dx;
                        self.soft.pos.y += dy;
                        for n in self.soft.body.nodes.iter_mut() {
                            n.p.x += dx;
                            n.p.y += dy;
                        }
                    }
                }
            }
        }
        if changed {
            let mut meta = std::mem::take(&mut self.scene.meta);
            meta.n_roads = st.scenes.values().map(|s| s.roads.len()).sum();
            meta.n_buildings = st.scenes.values().map(|s| s.buildings.len()).sum();
            meta.n_trees = st.scenes.values().map(|s| s.trees.len()).sum();
            let mut counts: std::collections::BTreeMap<String, usize> = Default::default();
            for sc in st.scenes.values() {
                for b in &sc.buildings {
                    *counts.entry(b.status.clone()).or_default() += 1;
                }
            }
            meta.status_counts = counts.into_iter().collect();
            self.scene.meta = meta;
        }
    }

    /// Nearest wide road among the loaded tiles, as a start pose in the current frame.
    fn find_spawn(&self) -> Option<scene::model::Spawn> {
        let st = self.stream.as_ref()?;
        let mut best: Option<(f64, scene::model::Spawn)> = None;
        for sc in st.scenes.values() {
            if !sc.roads.iter().any(|r| r.width >= 5.0) {
                continue;
            }
            let sp = sc.spawn();
            let d = sp.x.hypot(sp.y);
            if best.as_ref().map_or(true, |b| d < b.0) {
                best = Some((d, sp));
            }
        }
        best.map(|b| b.1)
    }

    fn stream_tick(&mut self) {
        let (cx, cy) = (self.car.pos.x, self.car.pos.y);
        let Some(st) = self.stream.as_mut() else { return };
        let ev = st.streamer.update(cx, cy);
        self.apply_stream_events(ev, true);
        let st = self.stream.as_mut().unwrap();
        if st.waiting {
            let center = TileId::from_lat_lon(st.origin_latlon.0, st.origin_latlon.1, ZOOM).key();
            let stats = st.streamer.stats();
            let have_center = st.scenes.contains_key(&center);
            let idle = stats.fetching == 0 && stats.building == 0;
            let gave_up = stats.loaded == 0 && stats.errors > 0 && st.wait_since.elapsed().as_secs() >= 3;
            if have_center || gave_up {
                if let Some(sp) = self.find_spawn() {
                    self.spawn = sp;
                } else if have_center && !idle {
                    return; // neighbouring tiles may still bring a road
                } else {
                    self.spawn = scene::model::Spawn { x: 0.0, y: 0.0, yaw: 0.0 };
                }
                self.place_car(self.spawn.x, self.spawn.y, self.spawn.yaw, 0.0);
                self.driver = Driver::new(self.car.p.steer_max);
                self.cam_yaw = self.spawn.yaw;
                self.stream.as_mut().unwrap().waiting = false;
            }
        }
    }

    pub fn load_scene(&mut self, scene: Scene) {
        self.spawn = scene.spawn();
        self.world = scene.static_world();
        self.meshes = scene_meshes(&scene);
        self.scene = scene;
        self.scene_dirty = true;
        self.respawn();
    }

    pub fn respawn(&mut self) {
        if let Some(st) = &self.stream {
            let (n, la, lo) = st.home.clone();
            self.teleport(&n, la, lo);
            return;
        }
        self.place_car(self.spawn.x, self.spawn.y, self.spawn.yaw, 0.0);
        self.driver = Driver::new(self.car.p.steer_max);
        self.cam_yaw = self.spawn.yaw;
    }

    /// Put the car back on its wheels where it is, pointing the same way, stopped.
    pub fn recover(&mut self) {
        let f = self.car.forward();
        let yaw = f.y.atan2(f.x);
        let (x, y) = (self.car.pos.x, self.car.pos.y);
        self.place_car(x, y, yaw, 0.0);
        self.driver = Driver::new(self.car.p.steer_max);
    }

    /// Held-key state. Returns true if the key was handled.
    pub fn key_state(&mut self, k: Key, down: bool) {
        match k {
            Key::Up => self.keys.up = down,
            Key::Down => self.keys.down = down,
            Key::Left => self.keys.left = down,
            Key::Right => self.keys.right = down,
            Key::Handbrake => self.keys.handbrake = down,
            _ if !down => {}
            Key::Camera => self.cam_mode = (self.cam_mode + 1) % 3,
            Key::HourUp => self.hour = (self.hour + 1.0) % 24.0,
            Key::HourDown => self.hour = (self.hour + 23.0) % 24.0,
            Key::Lights => {
                self.headlights = match self.headlights {
                    None => Some(true),
                    Some(true) => Some(false),
                    Some(false) => None,
                }
            }
            Key::SoftBody => {
                let f = self.car.forward();
                let yaw = f.y.atan2(f.x);
                let speed = self.car.telemetry().forward_speed;
                let (x, y) = (self.car.pos.x, self.car.pos.y);
                self.soft_on = !self.soft_on;
                self.place_car(x, y, yaw, speed);
                self.driver = Driver::new(self.car.p.steer_max);
            }
            Key::Respawn => self.respawn(),
            Key::Teleport => {
                if let Some(st) = self.stream.as_mut() {
                    st.preset = st.preset.wrapping_add(1) % PRESETS.len();
                    let (n, la, lo) = PRESETS[st.preset];
                    self.teleport(n, la, lo);
                }
            }
            Key::Recover => self.recover(),
            Key::Hud => self.show_hud = !self.show_hud,
            Key::Tcs => self.driver.tcs = !self.driver.tcs,
            Key::Abs => self.driver.abs = !self.driver.abs,
            Key::Help => self.show_help = !self.show_help,
        }
    }

    pub fn release_all(&mut self) {
        self.keys = Keys::default();
    }

    /// Advance the simulation by `dt` real seconds using fixed 1 ms physics steps.
    pub fn update(&mut self, dt: f64) {
        let dt = dt.clamp(0.0, 0.05);
        self.stream_tick();
        let frozen = self.stream.as_ref().map_or(false, |s| s.waiting);
        if frozen {
            self.acc = 0.0;
        } else {
            self.acc += dt;
        }
        let mut n = 0;
        while self.acc >= PHYS_DT {
            if self.soft_on {
                let fwd_speed = self.soft.vel.dot(self.soft.forward());
                let inp = self.driver.update(PHYS_DT, &self.keys, fwd_speed);
                self.soft.step(PHYS_DT, &inp, &self.ground, &self.world);
            } else {
                let fwd_speed = self.car.telemetry().forward_speed;
                let inp = self.driver.update(PHYS_DT, &self.keys, fwd_speed);
                self.car.step(PHYS_DT, &inp, &self.ground, &self.world);
            }
            self.acc -= PHYS_DT;
            n += 1;
        }
        if n > 0 {
            self.sync_from_soft_if_on();
        }
        self.sim_steps_last_frame = n;
        // camera follows the heading with a lag
        let f = self.car.forward();
        let yaw = f.y.atan2(f.x);
        let mut d = yaw - self.cam_yaw;
        d = d.sin().atan2(d.cos());
        self.cam_yaw += d * (dt * 3.2).min(1.0);
        // fps
        self.fps_acc += dt as f32;
        self.fps_n += 1;
        if self.fps_acc > 0.5 {
            self.fps = self.fps_n as f32 / self.fps_acc;
            self.fps_acc = 0.0;
            self.fps_n = 0;
        }
    }

    fn headlights_on(&self, day: f32) -> bool {
        self.headlights.unwrap_or(day < 0.6)
    }

    pub fn frame_params(&self) -> FrameParams {
        let car = &self.car;
        let t = car.telemetry();
        let spd = t.speed;
        let cp = car.pos;
        let f = car.forward();
        let yaw = f.y.atan2(f.x);
        let (cy, sy) = (yaw.cos(), yaw.sin());
        let (eye, target, fov): (V3f, V3f, f32) = match self.cam_mode {
            0 => {
                let d = 7.5 + spd * 0.06;
                (
                    [(cp.x - self.cam_yaw.cos() * d) as f32, (cp.y - self.cam_yaw.sin() * d) as f32, (2.6 + spd * 0.012) as f32],
                    [(cp.x + cy * 3.0) as f32, (cp.y + sy * 3.0) as f32, 1.2],
                    (62.0 + spd * 0.25) as f32,
                )
            }
            1 => {
                let e = [(cp.x + cy * 0.25 - sy * 0.37) as f32, (cp.y + sy * 0.25 + cy * 0.37) as f32, 1.2];
                ([e[0], e[1], e[2]], [e[0] + cy as f32 * 20.0, e[1] + sy as f32 * 20.0, 1.1], 75.0)
            }
            _ => (
                [(cp.x - self.cam_yaw.cos() * 25.0) as f32, (cp.y - self.cam_yaw.sin() * 25.0) as f32, 60.0],
                [cp.x as f32, cp.y as f32, 0.0],
                55.0,
            ),
        };
        let (eye, target, fov) = self.cam_override.unwrap_or((eye, target, fov));
        let body = m4::mul(&m4::from_quat([car.q.w, car.q.x, car.q.y, car.q.z], [cp.x, cp.y, cp.z]), &m4::translate(0.0, 0.0, -CG_HEIGHT as f32));
        let mut wheels = [m4::id(); 4];
        for (i, w) in wheels.iter_mut().enumerate() {
            let c = car.wheel_center(i);
            let wl = &car.wheels[i];
            let r = m4::from_quat([car.q.w, car.q.x, car.q.y, car.q.z], [c.x, c.y, c.z]);
            *w = m4::mul(&m4::mul(&r, &m4::rot_z(wl.steer as f32)), &m4::rot_y(wl.spin as f32));
        }
        let lg = crate::env::lighting(self.hour);
        let braking = self.driver.brake > 0.2 || self.driver.handbrake > 0.0;
        FrameParams {
            eye,
            target,
            fov_deg: fov,
            body,
            wheels,
            draw_car: self.cam_mode != 1,
            car_pos: [cp.x as f32, cp.y as f32, 0.0],
            head_pos: [(cp.x + f.x * 2.3) as f32, (cp.y + f.y * 2.3) as f32, (cp.z + f.z * 2.3 + 0.2) as f32],
            head_dir: [f.x as f32, f.y as f32, f.z as f32 - 0.05],
            headlights: self.headlights_on(lg.day),
            braking,
            hour: self.hour,
            paint: [0.42, 0.04, 0.05],
        }
    }

    pub fn hud(&self) -> HudData {
        let t = self.car.telemetry();
        let m = &self.scene.meta;
        let mut lines = vec![
            format!("FPS {:.0}   DRAWS {}   TRIS {}K   TIME {:02}:00", self.fps, self.draws, self.triangles / 1000, self.hour as i32),
            format!("TCS {}   ABS {}   SIDESLIP {:.0} DEG   LAT {:.2} G", on_off(self.driver.tcs), on_off(self.driver.abs), t.side_slip.to_degrees().abs(), t.lat_g.abs()),
            format!("ROADS {}   BUILDINGS {}   TREES {}", m.n_roads, m.n_buildings, m.n_trees),
        ];
        let st: Vec<String> = m.status_counts.iter().map(|(k, v)| format!("{k} X{v}")).collect();
        if !st.is_empty() {
            lines.push(format!("BUILDINGS: {}", st.join(", ")));
        }
        lines.push(format!("TERRAIN: {}   FACADES: PROCEDURAL WINDOWS (NOT RECONSTRUCTION)", if m.terrain.is_empty() { "FLAT" } else { &m.terrain }));
        if let Some(st) = &self.stream {
            let ss = st.streamer.stats();
            let (la, lo, _) = st.streamer.frame().from_local(self.car.pos.x, self.car.pos.y, 0.0);
            lines.push(format!("{}   LAT {:.5}  LON {:.5}", st.place, la, lo));
            lines.push(format!(
                "TILES LOADED {}  FETCHING {}  BUILDING {}  ERRORS {}   NET {}  CACHE {}  {} KB",
                ss.loaded, ss.fetching, ss.building, ss.errors, ss.net_requests, ss.cache_hits, ss.bytes / 1024
            ));
            if st.waiting {
                lines.push(format!("LOADING THE MAP AROUND {} - CAR HELD UNTIL IT ARRIVES", st.place));
            }
            if let Some(e) = &ss.last_error {
                let e: String = e.chars().take(110).collect();
                lines.push(format!("LAST ERROR: {}", e.to_uppercase()));
            }
        }
        if self.soft_on {
            let (dmg, broken) = self.soft.damage();
            lines.push(format!("PHYSICS: SOFT-BODY NODE-BEAM ({} NODES, {} BEAMS)   BODY DAMAGE {:.0} CM   BROKEN BEAMS {}", self.soft.body.nodes.len(), self.soft.body.beams.len(), dmg * 100.0, broken));
        } else {
            lines.push("PHYSICS: RIGID BODY (F3 = SOFT-BODY)".to_string());
        }
        let locked: Vec<&str> = ["FL", "FR", "RL", "RR"].iter().enumerate().filter(|(i, _)| self.car.wheels[*i].locked).map(|(_, n)| *n).collect();
        if !locked.is_empty() {
            lines.push(format!("WHEELS LOCKED: {}", locked.join(" ")));
        }
        if self.keys.handbrake {
            lines.push("HANDBRAKE".to_string());
        }
        if self.car.impact > 500.0 {
            lines.push("COLLISION".to_string());
        }
        let help = if self.show_help {
            "W/S THROTTLE + BRAKE/REVERSE   A/D STEER   SPACE HANDBRAKE\nC CAMERA   [ ] TIME OF DAY   L LIGHTS   R RESPAWN+REPAIR   U RECOVER+REPAIR\nT TCS   B ABS   H HUD   F1 HELP   F2 TELEPORT   F3 SOFT/RIGID   ESC QUIT".to_string()
        } else {
            String::new()
        };
        HudData {
            speed_kmh: (t.forward_speed.abs() * 3.6) as f32,
            gear: t.gear,
            rpm: t.rpm as f32,
            rpm_max: self.car.p.drive.max_rpm as f32,
            lines,
            warn: match &m.source {
                Some(s) => format!("DATA: {s}"),
                None => "SYNTHETIC DEMO CITY - NOT REAL DATA".to_string(),
            },
            warn_is_demo: m.source.is_none() && self.stream.is_none(),
            help,
            show: self.show_hud,
        }
    }
}

/// Build the game for the chosen mode. `live` is the network client (only the Windows front end has one).
pub fn build_game(o: &crate::cli::Options, live: Option<Arc<dyn world::fetch::Fetcher>>, cache_dir: std::path::PathBuf) -> Result<Game, String> {
    use crate::cli::Mode;
    use world::cache::DiskCache;
    use world::fetch::VirtualOsm;
    use world::streamer::StreamConfig;
    const DEMO_SCENE: &str = include_str!("../../../data/demo_scene.json");
    const DEMO_OVERPASS: &str = include_str!("../../../data/demo_overpass.json");
    let name = if (o.lat, o.lon) == crate::cli::MINSK { "MINSK" } else { "CUSTOM PLACE" };
    let cache = || Some(DiskCache::new(&cache_dir, std::time::Duration::from_secs(30 * 24 * 3600)));
    match &o.mode {
        Mode::Demo => Ok(Game::new(Scene::from_json_str(DEMO_SCENE)?)),
        Mode::SceneFile(p) => {
            let text = std::fs::read_to_string(p).map_err(|e| format!("cannot read '{p}': {e}"))?;
            Ok(Game::new(Scene::from_json_str(&text).map_err(|e| format!("'{p}': {e}"))?))
        }
        Mode::Offline => {
            let v = Arc::new(VirtualOsm::from_overpass_json(DEMO_OVERPASS)?);
            let mut cfg = StreamConfig::default();
            cfg.min_request_interval = std::time::Duration::ZERO;
            Ok(Game::new_streaming(Streamer::new(cfg, v, None, o.lat, o.lon), name, o.lat, o.lon))
        }
        Mode::Live => {
            let f = live.ok_or("live streaming needs the Windows network client; use --offline or --demo here")?;
            Ok(Game::new_streaming(Streamer::new(StreamConfig::default(), f, cache(), o.lat, o.lon), name, o.lat, o.lon))
        }
    }
}

fn on_off(b: bool) -> &'static str {
    if b { "ON" } else { "OFF" }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn game() -> Game {
        let s = std::fs::read_to_string(concat!(env!("CARGO_MANIFEST_DIR"), "/../../data/demo_scene.json")).unwrap();
        Game::new(Scene::from_json_str(&s).unwrap())
    }

    #[test]
    fn throttle_moves_the_car_and_the_hud_reports_it() {
        let mut g = game();
        g.key_state(Key::Up, true);
        for _ in 0..300 {
            g.update(1.0 / 60.0);
        }
        let h = g.hud();
        assert!(h.speed_kmh > 20.0, "speed {}", h.speed_kmh);
        assert!(h.gear >= 1 && h.rpm > 1000.0);
        assert!(h.warn.contains("SYNTHETIC"));
        assert!(g.sim_steps_last_frame >= 16);
    }

    #[test]
    fn a_long_frame_does_not_stall_the_game_or_explode() {
        let mut g = game();
        g.key_state(Key::Up, true);
        g.update(5.0); // clamped to 50 ms
        assert!(g.sim_steps_last_frame <= 51);
    }

    #[test]
    fn respawn_and_recover() {
        let mut g = game();
        g.key_state(Key::Up, true);
        for _ in 0..200 {
            g.update(1.0 / 60.0);
        }
        g.key_state(Key::Up, false);
        let moved = g.car.pos.x;
        g.key_state(Key::Respawn, true);
        assert!(g.car.telemetry().speed < 1e-6);
        let _ = moved;
        // flip the car over, then recover
        g.car.q = phys::Quat::axis_angle(phys::V3::X, 3.0);
        g.key_state(Key::Recover, true);
        assert!(g.car.q.rotate(phys::V3::Z).z > 0.99);
    }

    #[test]
    fn cycling_options() {
        let mut g = game();
        for _ in 0..3 {
            g.key_state(Key::Camera, true);
        }
        assert_eq!(g.cam_mode, 0);
        g.key_state(Key::HourDown, true);
        assert_eq!(g.hour, 14.0);
        g.hour = 0.0;
        g.key_state(Key::HourDown, true);
        assert_eq!(g.hour, 23.0);
        g.key_state(Key::Lights, true);
        assert_eq!(g.headlights, Some(true));
        g.key_state(Key::Lights, true);
        g.key_state(Key::Lights, true);
        assert_eq!(g.headlights, None);
    }

    #[test]
    fn frame_params_are_finite_in_every_camera() {
        let mut g = game();
        g.key_state(Key::Up, true);
        for _ in 0..120 {
            g.update(1.0 / 60.0);
        }
        for mode in 0..3 {
            g.cam_mode = mode;
            let f = g.frame_params();
            let all: Vec<f32> = f.eye.iter().chain(&f.target).chain(&f.body).chain(f.wheels.iter().flatten()).copied().collect();
            assert!(all.iter().all(|v| v.is_finite()));
        }
        assert!(!g.frame_params().draw_car || g.cam_mode != 1);
    }

    #[test]
    fn handbrake_drift_does_not_bring_the_car_to_a_stop() {
        // The reported bug: holding the handbrake eventually stopped the car even with power applied.
        // Open ground (no buildings) so the test measures the physics, not a collision.
        let mut g = Game::new(Scene::default());
        g.key_state(Key::Up, true);
        for _ in 0..360 {
            g.update(1.0 / 60.0);
        }
        g.key_state(Key::Handbrake, true);
        g.key_state(Key::Left, true);
        for _ in 0..90 {
            g.update(1.0 / 60.0); // kick the tail out
        }
        g.key_state(Key::Left, false);
        for _ in 0..(60 * 15) {
            g.update(1.0 / 60.0); // keep throttle and handbrake held
        }
        assert!(g.car.telemetry().speed > 3.0, "stalled at {} m/s", g.car.telemetry().speed);
    }

    // ---------- streaming ----------
    fn offline_game() -> Game {
        let o = crate::cli::Options { mode: crate::cli::Mode::Offline, lat: crate::cli::MINSK.0, lon: crate::cli::MINSK.1, cache: None };
        build_game(&o, None, std::env::temp_dir()).unwrap()
    }

    fn run_until(g: &mut Game, secs: f64, mut f: impl FnMut(&Game) -> bool) -> bool {
        let t0 = std::time::Instant::now();
        while t0.elapsed().as_secs_f64() < secs {
            g.update(1.0 / 60.0);
            if f(g) {
                return true;
            }
            std::thread::sleep(std::time::Duration::from_millis(3));
        }
        false
    }

    fn settled(g: &Game) -> bool {
        let st = g.stream.as_ref().unwrap();
        let ss = st.streamer.stats();
        !st.waiting && ss.loaded >= 9 && ss.fetching == 0 && ss.building == 0
    }

    #[test]
    fn streaming_game_holds_the_car_then_places_it_on_a_road() {
        let mut g = offline_game();
        assert!(g.is_streaming());
        assert!(g.hud().lines.iter().any(|l| l.contains("LOADING")), "{:?}", g.hud().lines);
        assert!(run_until(&mut g, 15.0, |g| !g.hud().lines.iter().any(|l| l.contains("LOADING"))), "never left the loading state");
        let ops = g.take_render_ops();
        let adds = ops.iter().filter(|o| matches!(o, RenderOp::AddTile(..))).count();
        assert!(adds >= 1 && ops.iter().any(|o| matches!(o, RenderOp::FollowGround(true))));
        assert!(g.world.poly_count() > 0 && g.scene.meta.n_buildings > 0, "collision world should hold the loaded buildings");
        // the car sits on a wide road and can drive
        g.key_state(Key::Up, true);
        for _ in 0..180 {
            g.update(1.0 / 60.0);
        }
        assert!(g.car.telemetry().speed > 3.0);
        let h = g.hud();
        assert!(h.warn.contains("OPENSTREETMAP") && !h.warn_is_demo);
        assert!(h.lines.iter().any(|l| l.starts_with("TILES LOADED")));
    }

    #[test]
    fn teleport_swaps_the_world_and_freezes_the_car_until_it_is_ready() {
        let mut g = offline_game();
        assert!(run_until(&mut g, 15.0, settled));
        g.take_render_ops();
        let polys = g.world.poly_count();
        assert!(polys > 0);
        g.key_state(Key::Teleport, true); // first preset (Minsk) again: same data, must reload from scratch
        let ops = g.take_render_ops();
        assert!(ops.iter().any(|o| matches!(o, RenderOp::RemoveTile(_))));
        assert_eq!(g.world.poly_count(), 0, "old collision data must be gone immediately");
        let before = g.car.pos;
        g.update(0.016);
        assert!((g.car.pos - before).len() < 1e-9, "car must not move while waiting");
        assert!(run_until(&mut g, 15.0, settled));
        assert_eq!(g.world.poly_count(), polys, "same place must give the same collision world");
    }

    #[test]
    fn driving_far_rebases_without_teleporting_the_car() {
        let mut g = offline_game();
        assert!(run_until(&mut g, 15.0, |g| !g.hud().lines.iter().any(|l| l.contains("LOADING"))));
        let (la0, lo0, _) = g.stream.as_ref().unwrap().streamer.frame().from_local(g.car.pos.x, g.car.pos.y, 0.0);
        // push the car 4.5 km east (beyond the rebase distance) as a physics-free shift
        let fr = g.stream.as_ref().unwrap().streamer.frame();
        let p = fr.to_local(la0, lo0, 0.0);
        let _ = p;
        g.car.pos.x += 4500.0;
        g.soft.pos.x += 4500.0;
        for n in g.soft.body.nodes.iter_mut() {
            n.p.x += 4500.0;
        }
        let (la1, lo1, _) = fr.from_local(g.car.pos.x, g.car.pos.y, 0.0);
        g.update(0.016);
        let (la2, lo2, _) = g.stream.as_ref().unwrap().streamer.frame().from_local(g.car.pos.x, g.car.pos.y, 0.0);
        assert!((la1 - la2).abs() < 1e-7 && (lo1 - lo2).abs() < 1e-7, "geographic position must be preserved");
        assert!(g.car.pos.x.abs() < 50.0, "local coordinates restart near zero, got {}", g.car.pos.x);
    }

    // ---------- soft-body in the game ----------
    #[test]
    fn soft_body_is_the_default_and_f3_switches_models_keeping_pose_and_speed() {
        let mut g = Game::new(Scene::default());
        assert!(g.soft_on && g.deformed_body().is_none() == g.deformed.is_empty());
        g.key_state(Key::Up, true);
        for _ in 0..240 {
            g.update(1.0 / 60.0);
        }
        assert!(g.deformed_body().is_some());
        let (p, v) = (g.car.pos, g.car.telemetry().forward_speed);
        assert!(v > 5.0);
        g.key_state(Key::SoftBody, true);
        assert!(!g.soft_on && g.deformed_body().is_none());
        assert!((g.car.pos - p).len() < 0.3, "pose jumped {:?}", (g.car.pos - p).len());
        assert!((g.car.telemetry().forward_speed - v).abs() < 0.5);
        assert!(g.hud().lines.iter().any(|l| l.contains("RIGID")));
        for _ in 0..120 {
            g.update(1.0 / 60.0);
        }
        g.key_state(Key::SoftBody, true);
        assert!(g.soft_on && g.hud().lines.iter().any(|l| l.contains("SOFT-BODY")));
        assert!(g.car.telemetry().speed > 5.0, "should still be rolling");
    }

    #[test]
    fn driving_into_a_building_deforms_the_car_and_the_hud_reports_it_until_repaired() {
        let mut g = Game::new(Scene::default());
        g.world.add_poly(vec![(120.0, -20.0), (130.0, -20.0), (130.0, 20.0), (120.0, 20.0)]);
        g.key_state(Key::Up, true);
        let mut hit = false;
        for _ in 0..(60 * 40) {
            g.update(1.0 / 60.0);
            if g.car.impact > 500.0 {
                hit = true;
                break;
            }
        }
        assert!(hit, "never reached the wall, x = {}", g.car.pos.x);
        // hold throttle a moment longer so the nose really loads
        for _ in 0..30 {
            g.update(1.0 / 60.0);
        }
        let (dmg, _) = g.soft.damage();
        let hud = g.hud();
        assert!(dmg > 0.05 || g.soft.body.beams.iter().any(|b| b.broken), "no damage after a crash? {dmg}");
        assert!(hud.lines.iter().any(|l| l.contains("BODY DAMAGE")));
        assert!(g.deformed_body().unwrap().iter().all(|v| v.is_finite()));
        g.key_state(Key::Respawn, true);
        assert!(g.soft.damage().0 < 1e-6, "respawn must repair the car");
    }
}
